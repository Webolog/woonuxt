<template>
  <div class="container min-h-[600px]">
    <ResetPassword />
  </div>
</template>
